﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4People.StatisticalTestTask
{
    public static class Constants
    {
        public static readonly string Caption = "Warning!";
        public static readonly string LogDir = "C:\\output";
        public static readonly string LogFile =  "SavedList.txt";
    }
}
