﻿using _4People.StatisticalTestTask.Model;
using _4People.StatisticalTestTask.Model.Strategy;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace _4People.StatisticalTestTask.ViewModel
{
    public class Presenter : ObservableObject
    {
        private readonly List<OutComesModel> _ensemble = new List<OutComesModel>();
        private string _res;
        private int _timeLeft;
        private int _NNumber, _upper, _lower;
        private string _inputfilepath;
        private int _hosts, _guests;
        private double _phost, _pguest, _pdeadheat, _pstuck;

        public int Upper
        {
            get
            {
                return _upper;
            }
            set
            {
                _upper = value;
                if (_upper > Lower && Lower > 0)
                {
                    Number = _upper - Lower + Math.Max(CurrentHostScore, CurrentGuestScore);
                }

                RaisePropertyChangedEvent("Upper");
            }           
        
        }
        public int Lower
        {
            get
            {
                return _lower;
            }
            set
            {
                _lower = value;
                if (Upper > _lower && _lower>0)
                {
                    Number = Upper - _lower + Math.Max(CurrentHostScore,CurrentGuestScore);
                } 
                RaisePropertyChangedEvent("Lower");
            }

        }

        public int CurrentGuestScore
        {
            get
            {
                return _guests;
            }
            set
            {
                _guests = value;
                RaisePropertyChangedEvent("CurrentGuestScore");
            }
        }
        public int CurrentHostScore
        {
            get
            {
                return _hosts;
            }
            set
            {
                _hosts = value;
                RaisePropertyChangedEvent("CurrentHostScore");
            }
        }

        public string InputFilePath
        {
            get
            {
                return _inputfilepath;
            }
            set
            {
                _inputfilepath = value;
                RaisePropertyChangedEvent("InputFilePath");
            }
        }

        public string Result
        {
            get { 
                return _res; 
            }
            set
            {
                _res = value;
                RaisePropertyChangedEvent("Result");
            }
        }


        /// <summary>
        /// Probabilities
        /// </summary>
        public double PHosts
        {
            get
            {
                return _phost;
            }
            set
            {
                _phost = value;
                RaisePropertyChangedEvent("PHosts");
            }
        }

        public double PGuests
        {
            get
            {
                return _pguest;
            }
            set
            {
                _pguest = value;
                RaisePropertyChangedEvent("PGuests");
            }
        }
        public double PDeadHeat
        {
            get
            {
                return _pdeadheat;
            }
            set
            {
                _pdeadheat = value;
                RaisePropertyChangedEvent("PDeadHeat");
            }
        }
        public double PStuck
        {
            get
            {
                return _pstuck;
            }
            set
            {
                _pstuck = value;
                RaisePropertyChangedEvent("PStuck");
            }
        }




        public int TimeLeft
        {
            get
            {
                return _timeLeft;
            }
            set
            {
                _timeLeft = value;
                RaisePropertyChangedEvent("TimeLeft");
            }
        }
        public int Number
        {
            get
            {
                return _NNumber;
            }
            set
            {
                _NNumber = value;
                RaisePropertyChangedEvent("Number");
            }

        }
        public ICommand EstimateCommand
        {
            get { return new DelegateCommand(Estimate); }
        }
        public ICommand BrowseDataCommand
        {
            get { return new DelegateCommand(BrowseData); }
        }
        public List<int> NumberOutcomesInterval
        {
            get
            {
                return new List<int> {1, 2, 3, 4, 5, 6 };
            }
        }
        public List<int> GoalsInterval
        {
            get {
                return new List<int> { 0,1,2,3,4,5,6};
            }
        }

        private void Estimate()
        {
            //if (Upper >= Lower)
            //{
            if (_ensemble.Count > 0)
            {
                if (Number > 0)
                {

                    //Result is critical Undoing
                    if (CurrentHostScore + Number < CurrentGuestScore)
                    {
                        var estimator = new StatisticalEnsemble(new GuestsVictory(), _ensemble);
                        PGuests = estimator.Estimate(Number, CurrentGuestScore, CurrentHostScore, TimeLeft);
                        //others will stay zeros
                        PHosts = 0.0;
                        PDeadHeat = 0.0;
                    } else
                    //Result is critical Undoing
                    if (CurrentGuestScore + Number < CurrentHostScore)
                    {
                        var estimator = new StatisticalEnsemble(new HostsVictory(), _ensemble);
                        PHosts = estimator.Estimate(Number, CurrentGuestScore, CurrentHostScore, TimeLeft);
                        //others will stay zeros
                        PGuests = 0.0;
                        PDeadHeat = 0.0;

                    } else
                    //if ((CurrentHostScore+ Number+CurrentGuestScore)%2!=0)
                    //{
                    //    PDeadHeat = 0.0;

                    //    var estimatorGuest = new StatisticalEnsemble(new GuestsVictory(), _ensemble);
                    //    var estimatorHosts = new StatisticalEnsemble(new HostsVictory(), _ensemble);
                    //    var estimatorStuck = new StatisticalEnsemble(new Stuck(), _ensemble);

                    //    PHosts = estimatorHosts.Estimate(Number, CurrentGuestScore, CurrentHostScore, TimeLeft);
                    //    PGuests = estimatorGuest.Estimate(Number, CurrentGuestScore, CurrentHostScore, TimeLeft);
                    //    PStuck = estimatorStuck.Estimate(Number, CurrentGuestScore, CurrentHostScore, TimeLeft);
                    //}
                    //else
                    {
                        var estimatorDeadHeat = new StatisticalEnsemble(new DeadHeat(), _ensemble);
                        var estimatorGuest = new StatisticalEnsemble(new GuestsVictory(), _ensemble);
                        var estimatorHosts = new StatisticalEnsemble(new HostsVictory(), _ensemble);
                        var estimatorStuck = new StatisticalEnsemble(new Stuck(), _ensemble);

                        PHosts = estimatorHosts.Estimate(Number, CurrentGuestScore, CurrentHostScore, TimeLeft);
                        PGuests = estimatorGuest.Estimate(Number, CurrentGuestScore, CurrentHostScore, TimeLeft);
                        PDeadHeat = estimatorDeadHeat.Estimate(Number, CurrentGuestScore, CurrentHostScore, TimeLeft);
                        PStuck = estimatorStuck.Estimate(Number, CurrentGuestScore, CurrentHostScore, TimeLeft);

                    }
                }
                else
                {
                    MessageBox.Show("Incorrect interval's boundaries", Constants.Caption, MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else {
                MessageBox.Show("The statistical ensemble is empty!", Constants.Caption, MessageBoxButton.OK, MessageBoxImage.Warning);

            }

            //}else
            //{
            //    MessageBox.Show("Incorrect interval's boundaries",Constants.Caption,MessageBoxButton.OK, MessageBoxImage.Warning);
            //}

            //if (CurrentGuestScore + Number == CurrentHostScore)
            //{
            //    var estimator = new StatisticalEnsemble(new HostsVictory(), _ensemble);
            //    PHosts = estimator.Estimate(Number, CurrentGuestScore, CurrentHostScore, TimeLeft);
            //}
        }
        /// <summary>
        /// look for a matrix
        /// </summary>
        private void BrowseData()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            if (openFileDialog.ShowDialog() == true)
            {
                InputFilePath = openFileDialog.FileName;
                Calculate();


            }
        }



        private void Calculate()
        {
            try
            {
                using (StreamReader sr = new StreamReader(InputFilePath))
                {
                    string line;

                    while ((line = sr.ReadLine()) != null)
                    {
                        _ensemble.Add(new OutComesModel(line));
                    }

                    
                }
            }
            catch (Exception e)
            {
                // Let the user know what went wrong.
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
            }


        }


    }
}
