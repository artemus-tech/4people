﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4People.StatisticalTestTask.Model
{
    public class StatisticalEnsemble
    {
        private IMethod cases;
        private List<OutComesModel> StatisticsData;
        private double PriorProbability;

        public StatisticalEnsemble(IMethod method, List<OutComesModel> input)
        {
            cases = method;
            StatisticsData = input;
            PriorProbability = StatisticsData.Sum(x => x.P);

        }
        

        public double Estimate(int N, int CurGuestScore, int CurHostsScore, int timeLeft)
        {
            return cases.Estimate(N, CurGuestScore, CurHostsScore, timeLeft, StatisticsData)/PriorProbability;
        }
        



    }
}
