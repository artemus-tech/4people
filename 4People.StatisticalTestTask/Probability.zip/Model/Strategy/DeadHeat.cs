﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4People.StatisticalTestTask.Model.Strategy
{
    public class DeadHeat : AbstractCase, IMethod
    {


        public double Estimate(int N, int currentGuestPoints, int currentHostsPoints, int timeLeft, List<OutComesModel> data)
        {
            if (N > 0)
            { 
                
                var filter = data.Where(x => x.Guests + x.Hosts <= N + currentGuestPoints + currentHostsPoints && x.Guests == x.Hosts && x.GetLeader()>=Math.Max(currentGuestPoints, currentHostsPoints)).ToList();

                var sumPinRange = filter.Sum(x => x.P);
                
                Save(filter.Where(x => x.Guests + x.Hosts <= N + currentGuestPoints + currentHostsPoints && x.Guests == x.Hosts).ToList(), "DeadHeat");

                if (filter.Count == 0)
                {
                    throw (new Exception("Not enough data"));
                }

                return sumPinRange;
            }
            else
            {
                return currentHostsPoints == currentGuestPoints ? 1 : 0;
                //return data.Where(x => x.Guests == currentGuestPoints && x.Hosts == currentHostsPoints).Sum(x => x.P);
            }
        }
    }
}
