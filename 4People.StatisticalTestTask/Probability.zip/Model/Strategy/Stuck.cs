﻿using _4People.StatisticalTestTask.Model.Strategy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4People.StatisticalTestTask.Model
{
    public class Stuck : AbstractCase, IMethod
    {
        public double Estimate(int N, int currentGuestPoints, int currentHostsPoints, int timeLeft, List<OutComesModel> data)
        {

            var filter = data.Where(x => x.Guests == currentGuestPoints && x.Hosts == currentHostsPoints).ToList();
            Save(filter,"Stuck");

            return data.Where(x => x.Guests == currentGuestPoints && x.Hosts == currentHostsPoints).Sum(x => x.P);
            

        }
    }
}
