﻿using _4People.StatisticalTestTask.Model.Strategy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4People.StatisticalTestTask.Model
{
    class GuestsVictory : AbstractCase, IMethod
    {
        public double Estimate(int N, int currentGuestPoints, int currentHostsPoints, int timeLeft, List<OutComesModel> data)
        {
            if (N > 0)
            {

                var filter = data.Where(x => x.Guests + x.Hosts <= currentGuestPoints + currentHostsPoints + N && x.Guests > x.Hosts && x.Hosts>=currentHostsPoints).ToList();
                Save(filter,"Guest");

                if (filter.Count == 0)
                {
                    throw (new Exception("Not enough data"));
                }


                return filter.Sum(x=>x.P);
            }
            else {
                return currentGuestPoints > currentHostsPoints ? 1 : 0;
                //return data.Where(x => x.Guests == currentGuestPoints && x.Hosts == currentHostsPoints).Sum(x => x.P);
            }



        }
    }
}
